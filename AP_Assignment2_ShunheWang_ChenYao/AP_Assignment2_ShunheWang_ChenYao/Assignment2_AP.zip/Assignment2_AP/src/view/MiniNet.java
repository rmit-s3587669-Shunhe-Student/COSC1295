package view;

public class MiniNet {

	public static void main(String[] args) {
		new MainInterface();
	}

}
